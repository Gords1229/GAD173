#pragma once

class Example {
private:
	int x;
public:
	Example(int j);
	void SetX(int i);
	int GetX();
};