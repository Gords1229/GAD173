#include <iostream>
#include "Header.h"

using namespace std;

int main()
{
	Example example(99);

	//example.SetX(5);

	cout << example.GetX() << endl;
}