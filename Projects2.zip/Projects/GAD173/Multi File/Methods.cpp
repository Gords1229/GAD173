#include "Header.h"

Example::Example(int z) 
{
	x = z;
}

void Example::SetX(int i)
{
	x = i;
}

int Example::GetX()
{
	return x;
}