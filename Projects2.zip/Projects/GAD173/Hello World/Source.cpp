// my first program in C++
/* comments can be written like this as well*/
#include <iostream>
using namespace std;

int main()
{
	int i = 99;
	float PI = 2 * asin(1);
	bool on = true;
	string s = "the current date and time is ";

	cout << "i = " << i << endl;
	cout << "PI = " << PI << endl;
	cout << "on is " << on << endl;

	cout << "Hello World!\n";
	cout << "I am learning C++";

	/*
	90 degrees = PI/2;

	sin(90) = 1;

	sin(PI/2) = 1;

	PI = 2*asin(1)
	
	*/
}